---
title: 'First Post - Introduction'
date: 2018-12-01 07:00:00
author: 'John Doe'
image: ../../images/javascript.jpg
tags:
  - code
---

Welcome to Code Blog, I hope you enjoy the content, Welcome to Code Blog, I hope you enjoy the content, Welcome to Code Blog, I hope you enjoy the content, Welcome to Code Blog, I hope you enjoy the content, Welcome to Code Blog, I hope you enjoy the content.
